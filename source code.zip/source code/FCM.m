function [U, center] =  FCM( data, cluster_n, center_ini)
m = 2.0;
iterMax = 150;
thred = 1e-4;
center = center_ini;
data_dim = size(data,2);

for t = 1:iterMax
    center_old = center;
    dist = pdist2(center, data);       % fill the distance matrix
    tmp = dist.^(-2/(m-1));
    U = tmp./(ones(cluster_n, 1)*sum(tmp));
     [row1, cow1] = find(dist==0);
    U(row1, cow1) = 1;
    tmp = U.^m;
    center = tmp*data./(sum(tmp,2)*ones(1,data_dim));
    
    if t>1
        if max(abs(center_old-center)) < thred
            break;
        end
    end
end