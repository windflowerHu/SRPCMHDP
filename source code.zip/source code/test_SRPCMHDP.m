clc;
clear;
close all;

num_K = 15;
m = 2.0;
alpha = 5.3;
lamda = 1.5;
thred = 1e-4;

dataname = 'aggregation';
data = load(strcat('./datasets/data_',dataname,'.txt'));
ground_truth = load(strcat('./datasets/label_',dataname,'.txt'));
[n_data,n_D] = size(data);
n_clusters_re = max(ground_truth);

distdata = pdist(data);
dist_data = squareform(distdata);
[numClust_new, centId_new] = DBKE(data,num_K);
[ID_new, ~] = find(centId_new ~=0);
label_ID = ground_truth(ID_new);
G = data(ID_new,:);

n_clusters_ini = 3*size(G,1);

tmp_indx = randperm(n_data, n_clusters_ini);
center_ini = data(tmp_indx,:);

[U,center,clusters_n_change] = SRPCMHDP(data,G,alpha,lamda,m,center_ini,n_clusters_ini);
center_n_end = clusters_n_change(end);
[~,tmp_label] = sort(U);
label_all = tmp_label(end,:);
