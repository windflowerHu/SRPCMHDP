function [numClust_new, centId_new] = DBKE(data,num_K)
    delta = inf*ones([size(data,1) 1]);
    data_size = size(data,1);

    density = zeros(data_size,1);
    for i=1:data_size
        tmp_dist = pdist2(data(i,:),data);
        sortDist = sort(tmp_dist,2);
        density(i,1) =  sum(sortDist(:,1:(num_K+1)), 2);
    end
    density = density./num_K;


    [~, ordDensity] = sort(density);
    for i = 2 : data_size
        tmp_dist = pdist2(data(ordDensity(i),:),data);
        delta(ordDensity(i)) = min(tmp_dist(:, ordDensity(1:i-1)));
    end
    tmp_dist = pdist2(data(ordDensity(1),:),data);
    delta(ordDensity(1)) = max(tmp_dist);


    
    h = figure();
    set(h,'name','���㷨�ܶ�ͼ');
    cla reset
    line(density, delta);
    plot(density(:),delta(:),'o','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
    set(gca,'FontSize',35);
    set(gca,'looseInset',[0 0 0 0]);
    axis([0,max(max(density))+0.5,0,max(max(delta))+0.2]);
    box on;
    xlabel('\it\rho','FontSize',25);
    ylabel('\it\delta','FontSize',25);

    
    


% %%�ֶ�ѡȡ��������
fprintf('ѡ���������\n');
rectangle1 = getrect(h);
minDensity = rectangle1(1);
maxDensity = minDensity + rectangle1(3);
minDelta = rectangle1(2);
maxDelta = minDelta+rectangle1(4);
centId_new = zeros(size(data,1), 1);
numClust_new = 0;
for i = 1:size(data,1)
    if((density(i) >minDensity)&&(delta(i) > minDelta)&&(density(i) <maxDensity))
        numClust_new = numClust_new+1;
        fprintf('%d,%f,%f\n',i,density(i),delta(i));
        density1(numClust_new,1) = density(i);
        delta1(numClust_new,1) = delta(i);
        choosed(numClust_new,1) = i;
        index(numClust_new,1) = i;
        centId_new(i) = numClust_new;
    end
end

index2 = setdiff([1:data_size]',index);
density2 = density(index2);
delta2 = delta(index2);

cmap=colormap;
% 
for i=1:numClust_new
   ic=int8((i*64.)/(numClust_new*1.));
%    subplot(2,1,1)
   hold on
   plot(density(choosed(i)),delta(choosed(i)),'o','MarkerSize',8,'MarkerFaceColor',cmap(ic,:),'MarkerEdgeColor',cmap(ic,:));
%    hold on
end

