function [U,center,center_n_change] = SRPCMHDP(data,G,alpha,lamda,m,center_ini,n_clusters_ini)
iter_max = 250;
min_impro = 1e-4;
data_n = size(data,1);
data_dim = size(data,2);

[U_FCM, center_FCM] = FCM( data, n_clusters_ini, center_ini);


center = center_FCM;
eta = sum(U_FCM.*pdist2(center_FCM,data),2)./sum(U_FCM,2);
eta_mean = mean(eta);

center_n_change(1) = n_clusters_ini;
remove_label = cell(iter_max,1);

for t = 2:iter_max
    center_2 = center;
    
    U_old = exp(-alpha*(pdist2(center, data).^2)./(eta_mean*eta*ones(1,data_n)));
    tmp = (pdist2(center,G)).^(-2/(m-1));
    r = tmp./(ones(size(center,1), 1)*sum(tmp));
    center_old = (U_old*data+lamda*r*G)./((sum(U_old,2)+lamda*sum(r,2))*ones(1,data_dim));

    [~,tmp_label] = sort(U_old);
    label = tmp_label(end,:);
    remain = unique(label);
    remove_label{t,1} = setdiff(1:center_n_change(t-1),remain);
    U = U_old(remain,:);
    center = center_old(remain,:);
    r = r(remain,:);
    center_n_change(t,1) = size(remain,2);

    if center_n_change(t,1)==1
        label = ones(size(data,1),1);
    else
        [~,tmp_label] = sort(U);
        label = tmp_label(end,:);
    end
    label_sum = tabulate(label(:));

    eta_tmp = zeros(center_n_change(t),1);
    for j = 1:center_n_change(t)

        if center_n_change(t)==1
            U_j = U;
        else
            U_j = U(:,label==j);
            U_j = max(U_j);
        end
        mean_U = mean(U_j);
        tmp_dx = find(label==j);
        re_dx = tmp_dx(U_j>=mean_U);
        if length(re_dx) == 1
            eta_tmp(j) = 0;
        else
            eta_tmp(j) = sum(pdist2(data(re_dx,:),mean(data(re_dx,:))))/length(re_dx);
        end
    end
    eta = eta_tmp;

    
    if t>2
        if size(U,1) == 1
            break;
        end

        if center_n_change(t) == center_n_change(t-1)
            if max(abs(center_2-center))<min_impro
            % if max(abs(U_2-U))<min_impro
                break;
            end
        end
    end
end
